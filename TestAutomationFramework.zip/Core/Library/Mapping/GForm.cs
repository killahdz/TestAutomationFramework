﻿using System.Collections.Generic;

namespace Core.Library.Mapping
{
    public class GForm
    {
        public IEnumerable<NameMap> NameMap { get; set; }
    }
}