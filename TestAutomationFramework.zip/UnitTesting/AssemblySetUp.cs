﻿using NUnit.Framework;

// Enable NUnit 3 Parallelisation.
[assembly: Parallelizable(ParallelScope.None)]
[assembly: LevelOfParallelism(2)]

